# Module 3: Claude-only orchestration (Opus · Sonnet · Haiku)

Opus plans and scores. Haiku scouts and does simple edits. Sonnet builds the normal work and reviews normal tasks. Opus builds only the hardest tasks and reviews the large or sensitive ones. An Opus fixer takes over after repeated failures. Everything runs inside your Claude Pro plan. No other subscription is needed.

Tuned for Pro limits: the 5-hour and weekly limits are shared with claude.ai.

## What's in the zip

```
Module-3/
├── install.sh             ← one-command installer (Mac, Linux, Git Bash)
├── install.ps1            ← one-command installer (Windows PowerShell)
├── settings.json          ← the approvals list the installer adds
├── CLAUDE.md              ← the orchestrator's rules (routing, scoring, review loop)
├── SETUP.md               ← setup steps Claude Code follows
└── agents/
    ├── scout.md           ← Haiku · read-only search and research
    ├── haiku-implementer.md ← Haiku · simple, fully specified edits
    ├── implementer.md     ← Sonnet · default builder
    ├── opus-implementer.md ← Opus · hard diagnosis, security, architecture
    ├── reviewer.md        ← Sonnet · default reviewer
    ├── opus-reviewer.md   ← Opus · reviews large/sensitive tasks
    └── fixer.md           ← Opus · takes over after failed reviews
```

## What you need

- A Claude Pro plan (or higher)
- The Claude Code desktop app, or the Claude Code CLI
- The files in this folder, downloaded from GitHub (or `module-3-files.zip`, unzipped)

## Setup (Mac and Windows)

**Easiest: let Claude Code set it up**

1. Put `module-3-files.zip` in your project folder.
2. Open the Claude desktop app. Click **New session** and pick your project folder.
3. Paste this line:
   ```
   Unzip module-3-files.zip in this folder, then read Module-3/SETUP.md and follow it.
   ```

Claude Code unzips the files, asks you one question (may it edit files without asking each time), installs the module and tells you what is left. It will ask your approval for the first one or two commands; that is normal, the approvals list does not exist yet. When it finishes, start a new session and choose Opus.

**Or run the installer yourself**

1. **Create the project folder.** Any name, anywhere. Example: `my-app`.
2. **Unzip `module-3-files.zip` inside `my-app`.** It creates a `Module-3` folder.
3. **Open a terminal in the folder.**
   - Mac: right-click `my-app` > **New Terminal at Folder**. (If missing: System Settings > Keyboard > Keyboard Shortcuts > Services.)
   - Windows: open `my-app` in File Explorer, click the address bar, type `powershell` and press Enter.
4. **Run one command.**
   - Mac:
     ```
     bash Module-3/install.sh
     ```
   - Windows (PowerShell):
     ```
     powershell -ExecutionPolicy Bypass -File Module-3\install.ps1
     ```

It prints one line per step. Running it again is safe: it changes nothing the second time.

The installer asks one question: may Claude edit files in this folder without asking each time? Answer `y` for runs you can leave alone, or `n` to approve each edit yourself. To answer yes up front, add `--accept-edits` to the Mac command or `-AcceptEdits` to the Windows command. You can change it later in `.claude/settings.json`.

**What it does**
- Copies the 7 agents to `.claude/agents/`.
- Copies `CLAUDE.md`. If you already have your own, it does not overwrite it: it saves the new text as `CLAUDE.module-3.md` and tells you to paste it in. An older Module 3 copy is backed up and replaced.
- Adds the approvals list to `.claude/settings.json` (merged, your other settings stay).
- Asks the one edit question described above and, only if you say yes, sets `"defaultMode": "acceptEdits"` in that file.
- Starts git and makes a first commit if the folder has none. It never touches an existing repo or your `.env` files.

<details>
<summary>Manual install (only if you prefer to copy by hand)</summary>

1. Copy `CLAUDE.md` and the `agents` folder from `Module-3` into `my-app`.
2. Move `agents` into the hidden `.claude` folder:
   - Mac:
     ```
     mkdir -p .claude && mv agents .claude/agents
     ```
   - Windows (PowerShell):
     ```
     New-Item -ItemType Directory -Force .claude | Out-Null; Move-Item agents .claude\agents
     ```
3. Optional: copy `Module-3/settings.json` to `.claude/settings.json` (the approvals list). If you already have that file, paste its lines into yours. Want Claude to edit files here without asking each time? Add `"defaultMode": "acceptEdits"` inside `"permissions"` in `.claude/settings.json`.
4. Reviews read `git diff`. If the folder is not a git repo yet, run `git init && git add -A && git commit -m "start"` once.

</details>

Result:

```
my-app/
├── CLAUDE.md
└── .claude/
    ├── agents/   ← the seven agent files
    └── settings.json
```

**Check it worked:** `ls -la .claude/agents`. You should see 7 files: `scout`, `haiku-implementer`, `implementer`, `opus-implementer`, `reviewer`, `opus-reviewer`, `fixer`.

5. **Start Claude Code in `my-app`.** Desktop app: **New session**, then pick the folder. CLI: type `claude` in the same terminal (Windows CLI needs Git for Windows).
6. **Choose Opus** in the model picker. The main chat must be Opus: it is the orchestrator.
7. **Test it:**

```
Add a README.md to this project with a one-paragraph description.
```

Opus should post a plan with a score and route per task, delegate, then report PASS or FAIL after a review. In the CLI, `/agents` lists all seven agents.

Don't rename any file: the agent names in `CLAUDE.md` must match the file names.

## Approvals
The installer adds an allow-list to `.claude/settings.json`: read-only commands such as `git status`, `git diff`, `git log`, `ls`, `wc` and `date`. So a run does not stop to ask for each one. It also blocks reading `.env` files. The installer also asks one question: may Claude edit files in this folder without asking each time? Yes sets `"defaultMode": "acceptEdits"` in that file (`--accept-edits` on Mac or `-AcceptEdits` on Windows answers yes up front); no leaves every edit asking as usual.

---

## How it behaves

1. **Plan.** Opus sends `scout` (Haiku) to look things up, then splits your request into tasks, grouped in waves. Shared foundations go first. Then independent tasks run in parallel, up to four at a time.
2. **Small jobs.** 2 tasks or fewer, nothing sensitive: one Sonnet build, one Sonnet review.
3. **Score.** Each task gets 0-2 on seven dimensions (ambiguity, novelty, coupling, reversibility, sensitivity, verifiability, diagnosis).
4. **Route.** Simple and checkable goes to Haiku. Normal work goes to Sonnet. Hard or sensitive work goes to Opus.
5. **Review.** Sonnet `reviewer` checks normal tasks. `opus-reviewer` checks large (over 5 files or ~400 lines), sensitive or Opus-built tasks.
6. **Fix.** One fix round by Sonnet, then `fixer` (Opus). After three failed reviews it stops and asks you.
7. **Log.** Each task is recorded in `TASKS.md` so you can tune the routing later.

## Saving Pro quota

- Send `/clear` between unrelated pieces of work.
- Small jobs skip the full pipeline automatically. Each extra agent costs 45-80k tokens of setup.
- If you hit the 5-hour limit, wait for the reset. Weekly limits are shared with claude.ai chats.

## Troubleshooting

- **Opus writes code itself.** The main chat is not reading `CLAUDE.md`. Check it sits in the project root, then start a new session.
- **`/agents` shows nothing.** The files are not in `.claude/agents/`. Re-run the install command from inside `my-app`.
- **Can't see `.claude`.** Hidden folder. Mac: Cmd+Shift+. in Finder. Windows: File Explorer > View > Show > Hidden items.
- **Everything runs on Opus.** Make sure the model picker was set before the session started, and each agent file keeps its `model:` line.
